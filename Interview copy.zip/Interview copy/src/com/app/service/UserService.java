package com.app.service;

import com.app.model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UserService implements IUserService{
    public static HashMap<String, User> getRegisteredUser() {
        return registeredUser;
    }

    // name, phone, pin
    private static HashMap<String, User> registeredUser = new HashMap<>();

    @Override
    public User RegisterUser(String name, String phoneNumber, String pinCode) {
        User user = new User();
        user.setName(name);
        user.setPhoneNumber(phoneNumber);
        user.setPincode(pinCode);
        // generate hashcode userid
        //
        registeredUser.put(user.getUserId(), user);
        return user;
    }

    @Override
    public int SelfAssessmen(String userId, List<String> symptoms, boolean travelHistory, boolean contactWithCovidPatient, boolean positive) {
        User user = registeredUser.get(userId);

        user.setCovidPositive(positive);
        return 0;
    }
}
