package com.app.service;

import com.app.model.User;

import java.util.List;

public interface IUserService {

    public User RegisterUser(String name, String phoneNumber, String pinCode);
    public int SelfAssessmen(String userId, List<String> symptoms, boolean travelHistory, boolean contactWithCovidPatient, boolean positive);
}
