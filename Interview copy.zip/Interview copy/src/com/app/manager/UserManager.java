package com.app.manager;

import com.app.model.User;
import com.app.service.IUserService;
import com.app.service.UserService;

import java.util.ArrayList;
import java.util.List;

public class UserManager  {
    static UserService userService = new UserService();
    private static String name;
    private static String phoneNumber;
    private static String pinCode;
    private static String userId;
    private static List<String> symptoms;
    private static boolean travelHistory;
    private static boolean contactWithCovidPatient;


    // interview@barraiser.com


    public static String RegisterUser(String request) {
        User user;
        ProcessRequest(request);

        if(!name.equals("")){
            System.out.print("User Name is not valid");
            return null;
        }
        if(!(phoneNumber.equals("")) && phoneNumber.length() != 10){
            System.out.print("Phone Nummber is not valid");
            return null;
        }
        if(!pinCode.equals("") && phoneNumber.length() != 6){
            System.out.print("PinCode is not valid");
            return null;
        }

        user = userService.RegisterUser(name, phoneNumber, pinCode);
        return user.getUserId();
    }

    private static void ProcessRequest(String request) {
        String[] requestedAtributes =  request.split(",");
        for(String attribute : requestedAtributes){
            String[] keyVal = attribute.split(":");
            String key = keyVal[0];
            String value = keyVal[1];
            if(key.equals("name")){
                name = value;
            }else if(key.equals("phoneNumber")){
                phoneNumber = value;
            }else if(key.equals("pinCode")){
                pinCode = value;
            }
        }
    }

    public static int SelfAssessmen(String request) {
        ProcessSelfAssessmenRequest(request);
        int riskPercentage = 0;
        if(symptoms.size() > 0 && travelHistory == false && contactWithCovidPatient == false){
            riskPercentage = 5;
        }else if(symptoms.size() == 1 && travelHistory == true && contactWithCovidPatient == true){
            riskPercentage = 50;
        }else if(symptoms.size() == 2 && travelHistory == true && contactWithCovidPatient == true){
            riskPercentage = 75;
        }else{
            riskPercentage = 95;
        }
        return riskPercentage;
    }

    private static void ProcessSelfAssessmenRequest(String request) {
        String[] requestedAtributes =  request.split(",");
        for(String attribute : requestedAtributes){
            String[] keyVal = attribute.split(":");
            String key = keyVal[0];
            // String value = keyVal[1];
            if(key.equals("userId")){
                userId = keyVal[1];;
            }else if(key.equals("symptoms")){
                String[] strList = attribute.split(",");
                for(String symptom : strList){
                    symptoms.add(symptom);
                }
            }else if(key.equals("travelHistory")){
                boolean val = false;
                if(keyVal[1] == "true")
                    val = true;
                else
                    val = false;
                travelHistory = val;;
            }
            else if(key.equals("contactWithCovidPatient")){
                boolean val = false;
                if(keyVal[1] == "true")
                    val = true;
                else
                    val = false;
                contactWithCovidPatient = val;;
            }
        }

    }
}
























