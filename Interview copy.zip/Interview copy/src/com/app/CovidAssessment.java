package com.app;

import java.util.Scanner;

public class CovidAssessment {


}
