package com.app;

import com.app.model.User;
import com.app.service.IUserService;
import com.app.service.UserService;

import java.util.List;
import com.app.manager.UserManager;

import java.util.Scanner;

public class Main {
    public static UserManager userManager;
    public static User user;
    public static void main(String[] args) {
	// write your code here
        Scanner sc = new Scanner(System.in);
        // Register User"
        System.out.println("Please Register User");
        String  userDetails = sc.nextLine();
        String userid = UserManager.RegisterUser(userDetails);
        System.out.println("userId : "+ userid);
        // Self Assessment:
        String  assessmentDetails = sc.nextLine();
        int riskPercentage = UserManager.SelfAssessmen(assessmentDetails);
        System.out.println("riskPercentage : "+ userid); // "riskPercentage": 95}

        // Risk Calculation:
    }
}


 /*
    * Risk Calculation:
        No symptoms, No travel history, No contact with covid positive patient - Risk = 5%
        Any one symptom, travel history or contact with covid positive patient is true - Risk = 50%
        Any two symptoms, travel history or contact with covid positive patient is true - Risk = 75%
        Greater than 2 symptoms, travel history or contact with covid positive patient is true - Risk = 95%
        */
// {"userId":"1","symptoms":["fever","cold","cough"],"travelHistory":true,"contactWithCovidPatient":true}
